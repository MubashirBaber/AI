source scripts/setup_config.sh
cd airflow
# On finishing your run or to shut down the container/s
docker-compose down